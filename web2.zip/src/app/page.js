import Header from "./components/header/header";
import Banner from "./components/banner/banner";
import Menu from "./components/menu/menu";
import About from "./components/about/about";
import Contact from "./components/contact/contact";
import Footer from "./components/footer/footer";
import styles from "./page.module.css";

export default function Home() {
  return (
    <div className={styles.page}>
      <Header />
      <main className={styles.mainContent}>
        <Banner />
        <Menu />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
