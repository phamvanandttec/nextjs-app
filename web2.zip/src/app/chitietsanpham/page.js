export default function ChiTietSanPham() {
    return (
        <div>
            <h1>Chi tiết sản phẩm</h1>
        </div>
    );
}